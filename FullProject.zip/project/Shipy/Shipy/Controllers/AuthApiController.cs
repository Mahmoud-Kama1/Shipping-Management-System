using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shipy.Models.ViewModels;
using Shipy.Services;

namespace Shipy.Controllers;

[Route("api/[controller]")]
[ApiController]
public class AuthApiController : ControllerBase
{
    private readonly IAuthService _authService;

    public AuthApiController(IAuthService authService)
    {
        _authService = authService;
    }

    /// <summary>
    /// Login endpoint that returns JWT token
    /// </summary>
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        var (success, message, token, refreshToken) = await _authService.LoginAsync(model);

        if (!success)
        {
            return Unauthorized(new { message });
        }

        return Ok(new
        {
            message,
            token,
            refreshToken,
            expiresIn = 86400 // 24 hours in seconds
        });
    }

    /// <summary>
    /// Register endpoint
    /// </summary>
    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        var (success, message) = await _authService.RegisterAsync(model);

        if (!success)
        {
            return BadRequest(new { message });
        }

        return Ok(new { message });
    }

    /// <summary>
    /// Refresh token endpoint
    /// </summary>
    [HttpPost("refresh")]
    public async Task<IActionResult> RefreshToken([FromBody] RefreshTokenRequest request)
    {
        var (success, newToken) = await _authService.RefreshTokenAsync(request.Token, request.RefreshToken);

        if (!success || string.IsNullOrEmpty(newToken))
        {
            return Unauthorized(new { message = "Invalid token" });
        }

        return Ok(new
        {
            token = newToken,
            expiresIn = 86400
        });
    }

    /// <summary>
    /// Test endpoint to verify JWT authentication
    /// </summary>
    [Authorize(AuthenticationSchemes = "Bearer")]
    [HttpGet("test")]
    public IActionResult Test()
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        var email = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
        var name = User.FindFirst(System.Security.Claims.ClaimTypes.Name)?.Value;
        var role = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;

        return Ok(new
        {
            message = "JWT Authentication is working!",
            userId,
            email,
            name,
            role,
            claims = User.Claims.Select(c => new { c.Type, c.Value })
        });
    }
}

public class RefreshTokenRequest
{
    public string Token { get; set; } = string.Empty;
    public string RefreshToken { get; set; } = string.Empty;
}
