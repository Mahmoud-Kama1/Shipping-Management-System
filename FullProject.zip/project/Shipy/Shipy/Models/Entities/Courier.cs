namespace Shipy.Models.Entities;

public class Courier
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public bool IsAvailable { get; set; } = true;
    public string? ManagerId { get; set; }
    
    public User? Manager { get; set; }
    public ICollection<CourierGovernorate> CourierGovernorates { get; set; } = new List<CourierGovernorate>();
    public ICollection<Shipment> Shipments { get; set; } = new List<Shipment>();
}
