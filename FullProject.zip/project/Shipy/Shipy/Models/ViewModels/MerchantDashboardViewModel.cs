using Shipy.Models.Entities;

namespace Shipy.Models.ViewModels;

public class MerchantDashboardViewModel
{
    public List<Shipment> Shipments { get; set; } = new List<Shipment>();
    public int TotalShipments { get; set; }
    public int InTransit { get; set; }
    public int Delivered { get; set; }
    public int Pending { get; set; }
}
