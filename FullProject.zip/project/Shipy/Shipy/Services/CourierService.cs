using Microsoft.EntityFrameworkCore;
using Shipy.Data;
using Shipy.Models.Entities;
using Shipy.Models.ViewModels;

namespace Shipy.Services;

public interface ICourierService
{
    Task<List<Courier>> GetAllCouriersAsync();
    Task<Courier?> GetCourierByIdAsync(Guid id);
    Task<bool> CreateCourierAsync(CreateCourierViewModel model);
    Task<bool> UpdateCourierAsync(Guid id, UpdateCourierViewModel model);
    Task<bool> DeleteCourierAsync(Guid id);
    Task<bool> UpdateCourierAvailabilityAsync(Guid id, bool isAvailable);
    Task<List<Courier>> GetAvailableCouriersAsync();
    Task<bool> AssignGovernorateToCourierAsync(Guid courierId, int governorateId);
    Task<bool> RemoveGovernorateFromCourierAsync(Guid courierId, int governorateId);
}

public class CourierService : ICourierService
{
    private readonly ApplicationDbContext _context;

    public CourierService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<List<Courier>> GetAllCouriersAsync()
    {
        return await _context.Couriers
            .Include(c => c.Manager)
            .Include(c => c.CourierGovernorates)
            .ThenInclude(cg => cg.Governorate)
            .ToListAsync();
    }

    public async Task<Courier?> GetCourierByIdAsync(Guid id)
    {
        return await _context.Couriers
            .Include(c => c.Manager)
            .Include(c => c.CourierGovernorates)
            .ThenInclude(cg => cg.Governorate)
            .FirstOrDefaultAsync(c => c.Id == id);
    }

    public async Task<bool> CreateCourierAsync(CreateCourierViewModel model)
    {
        var courier = new Courier
        {
            Name = model.Name,
            Phone = model.Phone,
            ManagerId = model.ManagerId,
            IsAvailable = true
        };

        _context.Couriers.Add(courier);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> UpdateCourierAsync(Guid id, UpdateCourierViewModel model)
    {
        var courier = await _context.Couriers.FindAsync(id);
        if (courier == null) return false;

        courier.Name = model.Name;
        courier.Phone = model.Phone;
        courier.ManagerId = model.ManagerId;
        courier.IsAvailable = model.IsAvailable;

        _context.Couriers.Update(courier);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> DeleteCourierAsync(Guid id)
    {
        var courier = await _context.Couriers.FindAsync(id);
        if (courier == null) return false;

        _context.Couriers.Remove(courier);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> UpdateCourierAvailabilityAsync(Guid id, bool isAvailable)
    {
        var courier = await _context.Couriers.FindAsync(id);
        if (courier == null) return false;

        courier.IsAvailable = isAvailable;
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<List<Courier>> GetAvailableCouriersAsync()
    {
        return await _context.Couriers
            .Where(c => c.IsAvailable)
            .ToListAsync();
    }

    public async Task<bool> AssignGovernorateToCourierAsync(Guid courierId, int governorateId)
    {
        var exists = await _context.CourierGovernorates
            .AnyAsync(cg => cg.CourierId == courierId && cg.GovernorateId == governorateId);
        
        if (exists) return true;

        var assignment = new CourierGovernorate
        {
            CourierId = courierId,
            GovernorateId = governorateId
        };

        _context.CourierGovernorates.Add(assignment);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> RemoveGovernorateFromCourierAsync(Guid courierId, int governorateId)
    {
        var assignment = await _context.CourierGovernorates
            .FirstOrDefaultAsync(cg => cg.CourierId == courierId && cg.GovernorateId == governorateId);
        
        if (assignment == null) return false;

        _context.CourierGovernorates.Remove(assignment);
        return await _context.SaveChangesAsync() > 0;
    }
}
