namespace Shipy.Models.Entities;

public enum ShipmentStatus
{
    Pending,
    Accepted,
    Processing,
    InTransit,
    OutForDelivery,
    Delivered,
    Cancelled,
    Returned,
    Failed
}
