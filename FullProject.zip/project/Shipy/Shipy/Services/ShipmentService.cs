using Microsoft.EntityFrameworkCore;
using Shipy.Data;
using Shipy.Models.Entities;
using Shipy.Models.ViewModels;

namespace Shipy.Services;

public interface IShipmentService
{
    Task<List<Shipment>> GetAllShipmentsAsync();
    Task<Shipment?> GetShipmentByIdAsync(Guid id);
    Task<bool> CreateShipmentAsync(CreateShipmentViewModel model);
    Task<bool> UpdateShipmentAsync(Guid id, UpdateShipmentViewModel model);
    Task<bool> DeleteShipmentAsync(Guid id);
    Task<bool> UpdateShipmentStatusAsync(Guid id, ShipmentStatus status, string? notes, string userId);
    Task<List<Shipment>> GetShipmentsByCourierAsync(Guid courierId);
}

public class ShipmentService : IShipmentService
{
    private readonly ApplicationDbContext _context;

    public ShipmentService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<List<Shipment>> GetAllShipmentsAsync()
    {
        return await _context.Shipments
            .Include(s => s.Governorate)
            .Include(s => s.Courier)
            .Include(s => s.CreatedBy)
            .OrderByDescending(s => s.CreatedAt)
            .ToListAsync();
    }

    public async Task<List<Shipment>> GetShipmentsByCourierAsync(Guid courierId)
    {
        return await _context.Shipments
            .Include(s => s.Governorate)
            .Include(s => s.Courier)
            .Include(s => s.CreatedBy)
            .Where(s => s.CourierId == courierId)
            .OrderByDescending(s => s.CreatedAt)
            .ToListAsync();
    }

    public async Task<Shipment?> GetShipmentByIdAsync(Guid id)
    {
        return await _context.Shipments
            .Include(s => s.Governorate)
            .Include(s => s.Courier)
            .Include(s => s.CreatedBy)
            .Include(s => s.StatusHistory)
            .FirstOrDefaultAsync(s => s.Id == id);
    }

    public async Task<bool> CreateShipmentAsync(CreateShipmentViewModel model)
    {
        var governorate = await _context.Governorates.FindAsync(model.GovernorateId);
        if (governorate == null) return false;

        var shipment = new Shipment
        {
            SenderName = model.SenderName,
            SenderPhone = model.SenderPhone,
            RecipientName = model.RecipientName,
            RecipientPhone = model.RecipientPhone,
            RecipientAddress = model.RecipientAddress,
            Weight = model.Weight,
            Type = model.Type,
            ProductPrice = model.ProductPrice,
            DeliveryPrice = governorate.DeliveryFee, // Default to governorate fee
            GovernorateId = model.GovernorateId,
            CourierId = model.CourierId,
            Notes = model.Notes,
            CreatedById = model.CreatedById ?? "System", // Should be validated
            Status = ShipmentStatus.Pending
        };

        _context.Shipments.Add(shipment);
        
        // Add initial history
        var history = new ShipmentStatusHistory
        {
            ShipmentId = shipment.Id,
            Status = ShipmentStatus.Pending,
            Notes = "Shipment created",
            ChangedById = model.CreatedById
        };
        _context.ShipmentStatusHistories.Add(history);

        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> UpdateShipmentAsync(Guid id, UpdateShipmentViewModel model)
    {
        var shipment = await _context.Shipments.FindAsync(id);
        if (shipment == null) return false;

        shipment.SenderName = model.SenderName;
        shipment.SenderPhone = model.SenderPhone;
        shipment.RecipientName = model.RecipientName;
        shipment.RecipientPhone = model.RecipientPhone;
        shipment.RecipientAddress = model.RecipientAddress;
        shipment.Weight = model.Weight;
        shipment.Type = model.Type;
        shipment.ProductPrice = model.ProductPrice;
        shipment.DeliveryPrice = model.DeliveryPrice;
        shipment.GovernorateId = model.GovernorateId;
        shipment.CourierId = model.CourierId;
        shipment.Notes = model.Notes;
        shipment.UpdatedAt = DateTime.UtcNow;

        _context.Shipments.Update(shipment);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> DeleteShipmentAsync(Guid id)
    {
        var shipment = await _context.Shipments.FindAsync(id);
        if (shipment == null) return false;

        _context.Shipments.Remove(shipment);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> UpdateShipmentStatusAsync(Guid id, ShipmentStatus status, string? notes, string userId)
    {
        var shipment = await _context.Shipments.FindAsync(id);
        if (shipment == null) return false;

        shipment.Status = status;
        shipment.UpdatedAt = DateTime.UtcNow;

        var history = new ShipmentStatusHistory
        {
            ShipmentId = shipment.Id,
            Status = status,
            Notes = notes,
            ChangedById = userId
        };
        _context.ShipmentStatusHistories.Add(history);

        return await _context.SaveChangesAsync() > 0;
    }
}
