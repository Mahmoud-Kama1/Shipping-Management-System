using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shipy.Models.ViewModels;
using Shipy.Services;

namespace Shipy.Controllers;

[AllowAnonymous]
public class TrackingController : Controller
{
    private readonly ITrackingService _trackingService;

    public TrackingController(ITrackingService trackingService)
    {
        _trackingService = trackingService;
    }

    public async Task<IActionResult> Index(string? shipmentNumber)
    {
        if (string.IsNullOrEmpty(shipmentNumber))
        {
            return View(new TrackingViewModel());
        }

        var result = await _trackingService.TrackShipmentAsync(shipmentNumber);
        return View(result);
    }

    [HttpPost]
    public async Task<IActionResult> Track(string shipmentNumber)
    {
        if (string.IsNullOrWhiteSpace(shipmentNumber))
        {
            return View(new TrackingViewModel { Message = "Please enter a shipment number" });
        }

        var result = await _trackingService.TrackShipmentAsync(shipmentNumber);
        return View("Index", result);
    }

    [Authorize]
    public async Task<IActionResult> History()
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
        {
            return RedirectToAction("Login", "Account");
        }

        var history = await _trackingService.GetTrackingHistoryAsync(userId);
        return View(history);
    }
}
