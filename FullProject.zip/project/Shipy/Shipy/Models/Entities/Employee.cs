namespace Shipy.Models.Entities;

public class Employee
{
    public Guid Id { get; set; }
    public string UserId { get; set; } = string.Empty;
    public User User { get; set; } = null!;
    
    public string JobTitle { get; set; } = string.Empty;
    public string Position => JobTitle; // Alias
    public string Department { get; set; } = string.Empty;
    public DateTime HireDate { get; set; }
    public decimal Salary { get; set; }
    public bool IsActive { get; set; } = true;
    
    public string Phone { get; set; } = string.Empty;
    public string? Address { get; set; }
    public byte[]? ProfilePicture { get; set; }
}
