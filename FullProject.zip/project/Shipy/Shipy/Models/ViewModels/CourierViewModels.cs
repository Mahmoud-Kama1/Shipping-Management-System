using System.ComponentModel.DataAnnotations;

namespace Shipy.Models.ViewModels;

public class CreateCourierViewModel
{
    [Required]
    public string Name { get; set; } = string.Empty;
    [Required]
    public string Phone { get; set; } = string.Empty;
    public string? ManagerId { get; set; }
}

public class UpdateCourierViewModel : CreateCourierViewModel
{
    public bool IsAvailable { get; set; }
}
