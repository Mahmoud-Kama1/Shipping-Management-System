using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shipy.Models.ViewModels;
using Shipy.Models.Entities;
using Shipy.Services;

namespace Shipy.Controllers;

public class HomeController : Controller
{
    private readonly IMerchantService _merchantService;
    private readonly ITrackingService _trackingService;

    public HomeController(IMerchantService merchantService, ITrackingService trackingService)
    {
        _merchantService = merchantService;
        _trackingService = trackingService;
    }

    public async Task<IActionResult> Index()
    {
        if (User.Identity?.IsAuthenticated == true)
        {
            // Redirect to appropriate dashboard based on role
            var userRole = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;
            
            return userRole switch
            {
                "Admin" => RedirectToAction("Index", "Admin"),
                "Receptionist" => RedirectToAction("Index", "Receptionist"),
                "Courier" => RedirectToAction("Index", "CourierPanel"),
                "Merchant" => RedirectToAction("Index", "Merchant"),
                _ => View("~/Views/Merchant/Index.cshtml", new { Shipments = new List<object>() })
            };
        }

        // Show public landing page (Merchant Dashboard with dummy data)
        var dummyModel = new MerchantDashboardViewModel
        { 
            Shipments = new List<Shipment>(), // Empty list will trigger dummy data in view
            TotalShipments = 0,
            InTransit = 0,
            Delivered = 0,
            Pending = 0
        };
        return View("~/Views/Merchant/Index.cshtml", dummyModel);
    }

    [HttpPost]
    public async Task<IActionResult> TrackShipment(string shipmentNumber)
    {
        if (string.IsNullOrWhiteSpace(shipmentNumber))
        {
            TempData["Error"] = "Please enter a shipment number";
            return RedirectToAction(nameof(Index));
        }

        var result = await _trackingService.TrackShipmentAsync(shipmentNumber);
        
        if (!result.IsFound)
        {
            TempData["Error"] = result.Message;
            return RedirectToAction(nameof(Index));
        }

        return RedirectToAction("Index", "Tracking", new { shipmentNumber });
    }

    public IActionResult About()
    {
        return View();
    }

    public IActionResult Contact()
    {
        return View();
    }

    public IActionResult Services()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View();
    }
}
