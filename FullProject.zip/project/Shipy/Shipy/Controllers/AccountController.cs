using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shipy.Models.ViewModels;
using Shipy.Services;

namespace Shipy.Controllers;

[AllowAnonymous]
public class AccountController : Controller
{
    private readonly IAuthService _authService;

    public AccountController(IAuthService authService)
    {
        _authService = authService;
    }

    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        ViewData["ReturnUrl"] = returnUrl;
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl = null)
    {
        ViewData["ReturnUrl"] = returnUrl;
        if (ModelState.IsValid)
        {
            var result = await _authService.LoginAsync(model);
            
            if (result.Success)
            {
                // Cookie is already set by SignInManager.PasswordSignInAsync in AuthService
                
                TempData["Success"] = "Login successful!";
                
                if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                {
                    return Redirect(returnUrl);
                }
                
                return RedirectToAction("Index", "Home");
            }

            ModelState.AddModelError("", result.Message);
        }

        return View(model);
    }

    [HttpGet]
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (ModelState.IsValid)
        {
            var result = await _authService.RegisterAsync(model);
            
            if (result.Success)
            {
                TempData["Success"] = "Registration successful! Please login.";
                return RedirectToAction("Login");
            }

            ModelState.AddModelError("", result.Message);
        }

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        // Use AuthService or SignInManager directly if injected here, but AuthService handles logic
        // We need to call SignOutAsync. Since AuthService doesn't expose it directly in interface as void,
        // we should update AuthService or inject SignInManager here.
        // For cleaner architecture, let's assume AuthService.LogoutAsync handles it.
        
        // However, AuthService.LogoutAsync signature was (string refreshToken).
        // Let's update it to just LogoutAsync() and handle SignOut internally.
        
        await _authService.LogoutAsync(null); // Updated signature in next step

        return RedirectToAction("Login");
    }

    [HttpGet]
    public IActionResult AccessDenied()
    {
        return View();
    }
}
