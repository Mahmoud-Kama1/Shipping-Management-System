using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Shipy.Models.Entities;
using Shipy.Models.ViewModels;

namespace Shipy.Services;

public interface IAuthService
{
    Task<(bool Success, string Message, string? Token, string? RefreshToken)> LoginAsync(LoginViewModel model);
    Task<(bool Success, string Message)> RegisterAsync(RegisterViewModel model);
    Task LogoutAsync(string? refreshToken);
    Task<(bool Success, string? Token)> RefreshTokenAsync(string token, string refreshToken);
}

public class AuthService : IAuthService
{
    private readonly UserManager<User> _userManager;
    private readonly SignInManager<User> _signInManager;
    private readonly IConfiguration _configuration;
    private readonly INotificationService _notificationService;

    public AuthService(UserManager<User> userManager, SignInManager<User> signInManager, IConfiguration configuration, INotificationService notificationService)
    {
        _userManager = userManager;
        _signInManager = signInManager;
        _configuration = configuration;
        _notificationService = notificationService;
    }

    public async Task<(bool Success, string Message, string? Token, string? RefreshToken)> LoginAsync(LoginViewModel model)
    {
        var user = await _userManager.FindByEmailAsync(model.Email);
        if (user == null) return (false, "Invalid email or password", null, null);

        if (!user.IsActive) return (false, "Your account has been deactivated. Please contact administrator.", null, null);

        // Use PasswordSignInAsync to sign in with Cookies (for MVC)
        var result = await _signInManager.PasswordSignInAsync(user, model.Password, model.RememberMe, false);
        
        if (!result.Succeeded) return (false, "Invalid email or password", null, null);

        // Generate JWT Token for API/Mobile usage
        var token = await GenerateJwtTokenAsync(user);
        var refreshToken = GenerateRefreshToken();

        // Store refresh token (in a real app, save to database)
        // For now, returning the tokens
        return (true, "Login successful", token, refreshToken);
    }

    public async Task<(bool Success, string Message)> RegisterAsync(RegisterViewModel model)
    {
        var user = new User
        {
            UserName = model.Email,
            Email = model.Email,
            FirstName = model.FirstName,
            LastName = model.LastName,
            Role = model.Role,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };

        var result = await _userManager.CreateAsync(user, model.Password);
        if (!result.Succeeded) return (false, string.Join(", ", result.Errors.Select(e => e.Description)));

        await _userManager.AddToRoleAsync(user, model.Role);

        // Notify Admins
        var admins = await _userManager.GetUsersInRoleAsync(Roles.Admin);
        foreach (var admin in admins)
        {
            await _notificationService.SendNotificationAsync(admin.Id, "New Merchant Registration", $"A new merchant {user.FullName} ({user.Email}) has registered.");
        }

        return (true, "Registration successful");
    }

    public async Task LogoutAsync(string? refreshToken)
    {
        await _signInManager.SignOutAsync();
        // In a real app, invalidate the refresh token in database
    }

    public async Task<(bool Success, string? Token)> RefreshTokenAsync(string token, string refreshToken)
    {
        // In a real app, validate refresh token from database
        // For now, return success with new token
        var principal = GetPrincipalFromExpiredToken(token);
        if (principal == null) return (false, null);

        var userId = principal.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId)) return (false, null);

        var user = await _userManager.FindByIdAsync(userId);
        if (user == null || !user.IsActive) return (false, null);

        var newToken = await GenerateJwtTokenAsync(user);
        return (true, newToken);
    }

    private async Task<string> GenerateJwtTokenAsync(User user)
    {
        var roles = await _userManager.GetRolesAsync(user);
        
        var claims = new List<Claim>
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id),
            new Claim(ClaimTypes.Email, user.Email ?? string.Empty),
            new Claim(ClaimTypes.Name, user.FullName),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
        };

        // Add role claims
        foreach (var role in roles)
        {
            claims.Add(new Claim(ClaimTypes.Role, role));
        }

        var jwtKey = _configuration["Jwt:Key"];
        if (string.IsNullOrEmpty(jwtKey))
        {
            throw new InvalidOperationException("JWT Key is not configured");
        }

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: _configuration["Jwt:Issuer"],
            audience: _configuration["Jwt:Audience"],
            claims: claims,
            expires: DateTime.UtcNow.AddHours(24),
            signingCredentials: creds
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    private string GenerateRefreshToken()
    {
        var randomNumber = new byte[32];
        using var rng = RandomNumberGenerator.Create();
        rng.GetBytes(randomNumber);
        return Convert.ToBase64String(randomNumber);
    }

    private ClaimsPrincipal? GetPrincipalFromExpiredToken(string token)
    {
        var jwtKey = _configuration["Jwt:Key"];
        if (string.IsNullOrEmpty(jwtKey))
        {
            return null;
        }

        var tokenValidationParameters = new TokenValidationParameters
        {
            ValidateAudience = false,
            ValidateIssuer = false,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
            ValidateLifetime = false // Don't validate lifetime for refresh
        };

        var tokenHandler = new JwtSecurityTokenHandler();
        try
        {
            var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out SecurityToken securityToken);
            if (securityToken is not JwtSecurityToken jwtSecurityToken || 
                !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
            {
                return null;
            }
            return principal;
        }
        catch
        {
            return null;
        }
    }
}
