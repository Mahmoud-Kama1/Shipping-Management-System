using Shipy.Models.Entities;

namespace Shipy.Models.ViewModels;

public class TrackingViewModel
{
    public string ShipmentNumber { get; set; } = string.Empty;
    public bool IsFound { get; set; }
    public string Message { get; set; } = string.Empty;
    public Shipment? Shipment { get; set; }
}
