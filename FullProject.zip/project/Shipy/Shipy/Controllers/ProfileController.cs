using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Shipy.Models.Entities;
using Shipy.Models.ViewModels;
using Shipy.Services;

namespace Shipy.Controllers;

[Authorize]
public class ProfileController : Controller
{
    private readonly UserManager<User> _userManager;
    private readonly IEmployeeService _employeeService;
    private readonly INotificationService _notificationService;

    public ProfileController(UserManager<User> userManager, IEmployeeService employeeService, INotificationService notificationService)
    {
        _userManager = userManager;
        _employeeService = employeeService;
        _notificationService = notificationService;
    }

    public async Task<IActionResult> Index()
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
        {
            return RedirectToAction("Login", "Account");
        }

        var user = await _userManager.FindByIdAsync(userId);
        if (user == null)
        {
            return NotFound();
        }

        // Check if user is an employee
        var employee = await _employeeService.GetEmployeeByUserIdAsync(userId);

        var model = new PersonalDataViewModel
        {
            Id = user.Id,
            Email = user.Email!,
            FirstName = user.FirstName,
            LastName = user.LastName,
            Phone = user.PhoneNumber,
            Role = user.Role
        };

        if (employee != null)
        {
            model.Phone = employee.Phone;
            model.Address = employee.Address;
            model.ProfilePicture = employee.ProfilePicture;
        }

        // Check if user can edit their profile
        var userRole = user.Role;
        var canEdit = userRole == Roles.Merchant || userRole == Roles.Admin;
        ViewBag.CanEdit = canEdit;

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(PersonalDataViewModel model)
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
        {
            return RedirectToAction("Login", "Account");
        }

        var user = await _userManager.FindByIdAsync(userId);
        if (user == null)
        {
            return NotFound();
        }

        // Check if user has permission to edit
        var userRole = user.Role;
        var canEdit = userRole == Roles.Merchant || userRole == Roles.Admin;
        
        if (!canEdit)
        {
            TempData["Error"] = "You don't have permission to edit your profile.";
            return RedirectToAction(nameof(Index));
        }

        // Update user data
        user.FirstName = model.FirstName;
        user.LastName = model.LastName;
        user.PhoneNumber = model.Phone;

        var result = await _userManager.UpdateAsync(user);
        if (!result.Succeeded)
        {
            ModelState.AddModelError("", string.Join(", ", result.Errors.Select(e => e.Description)));
            return View("Index", model);
        }

        // Update employee data if exists
        var employee = await _employeeService.GetEmployeeByUserIdAsync(userId);
        if (employee != null)
        {
            // Only admin can edit employee data
            if (userRole == Roles.Admin)
            {
                var updateModel = new UpdateEmployeeViewModel
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Phone = model.Phone,
                    Address = model.Address,
                    ProfilePicture = model.ProfilePicture,
                    IsActive = employee.IsActive,
                    HireDate = employee.HireDate,
                    Salary = employee.Salary,
                    Position = employee.Position
                };

                await _employeeService.UpdateEmployeeAsync(employee.Id, updateModel);
            }
        }

        TempData["Success"] = "Profile updated successfully!";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> ChangePassword(string currentPassword, string newPassword, string confirmPassword)
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
        {
            return RedirectToAction("Login", "Account");
        }

        if (newPassword != confirmPassword)
        {
            TempData["Error"] = "New password and confirmation do not match.";
            return RedirectToAction(nameof(Index));
        }

        var user = await _userManager.FindByIdAsync(userId);
        if (user == null)
        {
            return NotFound();
        }

        var result = await _userManager.ChangePasswordAsync(user, currentPassword, newPassword);
        if (!result.Succeeded)
        {
            TempData["Error"] = string.Join(", ", result.Errors.Select(e => e.Description));
        }
        else
        {
            TempData["Success"] = "Password changed successfully!";
        }

        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Notifications()
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
        {
            return RedirectToAction("Login", "Account");
        }

        var notifications = await _notificationService.GetUserNotificationsAsync(userId);
        return View(notifications);
    }

    [HttpPost]
    public async Task<IActionResult> MarkNotificationRead(Guid id)
    {
        var result = await _notificationService.MarkAsReadAsync(id);
        return Json(new { success = result });
    }

    [HttpPost]
    public async Task<IActionResult> DeleteNotification(Guid id)
    {
        var result = await _notificationService.DeleteNotificationAsync(id);
        return Json(new { success = result });
    }
    [HttpGet]
    public async Task<IActionResult> GetUnreadNotificationCount()
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
        {
            return Json(new { count = 0 });
        }

        var count = await _notificationService.GetUnreadCountAsync(userId);
        return Json(new { count });
    }
}
