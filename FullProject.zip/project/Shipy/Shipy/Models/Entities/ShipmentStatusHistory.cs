namespace Shipy.Models.Entities;

public class ShipmentStatusHistory
{
    public Guid Id { get; set; }
    public Guid ShipmentId { get; set; }
    public Shipment Shipment { get; set; } = null!;
    
    public ShipmentStatus Status { get; set; }
    public string? Notes { get; set; }
    public string? ChangedById { get; set; }
    public DateTime ChangedAt { get; set; } = DateTime.UtcNow;
}
