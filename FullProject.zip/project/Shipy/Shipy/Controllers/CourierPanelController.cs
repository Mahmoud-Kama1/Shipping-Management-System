using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shipy.Models.Entities;
using Shipy.Models.ViewModels;
using Shipy.Services;

namespace Shipy.Controllers;

[Authorize(Roles = "Courier")]
public class CourierPanelController : Controller
{
    private readonly IShipmentService _shipmentService;
    private readonly ICourierService _courierService;

    public CourierPanelController(IShipmentService shipmentService, ICourierService courierService)
    {
        _shipmentService = shipmentService;
        _courierService = courierService;
    }

    public async Task<IActionResult> Index()
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
        {
            return RedirectToAction("Login", "Account");
        }

        // Get courier associated with this user
        var couriers = await _courierService.GetAllCouriersAsync();
        var courier = couriers.FirstOrDefault(c => c.ManagerId == userId);

        if (courier == null)
        {
            return View("NoCourierAssigned");
        }

        var shipments = await _shipmentService.GetShipmentsByCourierAsync(courier.Id);
        
        var dashboardData = new
        {
            Courier = courier,
            TotalShipments = shipments.Count,
            InTransitShipments = shipments.Count(s => s.Status == ShipmentStatus.InTransit),
            DeliveredShipments = shipments.Count(s => s.Status == ShipmentStatus.Delivered),
            PendingShipments = shipments.Count(s => s.Status == ShipmentStatus.Pending),
            Shipments = shipments.OrderByDescending(s => s.CreatedAt).ToList()
        };

        return View(dashboardData);
    }

    public async Task<IActionResult> MyShipments()
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
        {
            return RedirectToAction("Login", "Account");
        }

        var couriers = await _courierService.GetAllCouriersAsync();
        var courier = couriers.FirstOrDefault(c => c.ManagerId == userId);

        if (courier == null)
        {
            return View("NoCourierAssigned");
        }

        var shipments = await _shipmentService.GetShipmentsByCourierAsync(courier.Id);
        return View(shipments);
    }

    public async Task<IActionResult> ShipmentDetails(Guid id)
    {
        var shipment = await _shipmentService.GetShipmentByIdAsync(id);
        if (shipment == null)
        {
            return NotFound();
        }
        return View(shipment);
    }

    [HttpPost]
    public async Task<IActionResult> UpdateStatus(Guid id, ShipmentStatus status, string? notes = null)
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        var result = await _shipmentService.UpdateShipmentStatusAsync(id, status, notes, userId);
        
        if (result)
        {
            TempData["Success"] = $"Shipment status updated to {status}!";
        }
        else
        {
            TempData["Error"] = "Failed to update shipment status.";
        }

        return RedirectToAction(nameof(ShipmentDetails), new { id });
    }

    public async Task<IActionResult> Profile()
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
        {
            return RedirectToAction("Login", "Account");
        }

        var couriers = await _courierService.GetAllCouriersAsync();
        var courier = couriers.FirstOrDefault(c => c.ManagerId == userId);

        if (courier == null)
        {
            return View("NoCourierAssigned");
        }

        return View(courier);
    }

    [HttpPost]
    public async Task<IActionResult> UpdateAvailability(bool isAvailable)
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
        {
            return RedirectToAction("Login", "Account");
        }

        var couriers = await _courierService.GetAllCouriersAsync();
        var courier = couriers.FirstOrDefault(c => c.ManagerId == userId);

        if (courier == null)
        {
            return View("NoCourierAssigned");
        }

        var result = await _courierService.UpdateCourierAvailabilityAsync(courier.Id, isAvailable);
        
        if (result)
        {
            TempData["Success"] = $"Availability updated to {(isAvailable ? "Available" : "Unavailable")}!";
        }
        else
        {
            TempData["Error"] = "Failed to update availability.";
        }

        return RedirectToAction(nameof(Profile));
    }
}
