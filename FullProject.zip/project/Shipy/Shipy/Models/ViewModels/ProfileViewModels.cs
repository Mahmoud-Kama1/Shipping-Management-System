using System.ComponentModel.DataAnnotations;

namespace Shipy.Models.ViewModels;

public class PersonalDataViewModel
{
    public string Id { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string? Address { get; set; }
    public string Role { get; set; } = string.Empty;
    public byte[]? ProfilePicture { get; set; }
}

public class UpdateEmployeeViewModel
{
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string? Address { get; set; }
    public byte[]? ProfilePicture { get; set; }
    public bool IsActive { get; set; }
    public DateTime HireDate { get; set; }
    public decimal Salary { get; set; }
    public string Position { get; set; } = string.Empty;
}

public class CreateEmployeeViewModel : UpdateEmployeeViewModel
{
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}
