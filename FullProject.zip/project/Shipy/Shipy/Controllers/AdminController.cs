using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shipy.Models.ViewModels;
using Shipy.Services;

namespace Shipy.Controllers;

[Authorize(Roles = "Admin")]
public class AdminController : Controller
{
    private readonly INotificationService _notificationService;
    private readonly IEmployeeService _employeeService;
    private readonly IDashboardService _dashboardService;

    public AdminController(INotificationService notificationService, IEmployeeService employeeService, IDashboardService dashboardService)
    {
        _notificationService = notificationService;
        _employeeService = employeeService;
        _dashboardService = dashboardService;
    }

    public async Task<IActionResult> Index()
    {
        var notifications = await _notificationService.GetAdminNotificationsAsync();
        var unreadCount = await _notificationService.GetUnreadCountAsync(null);
        
        ViewBag.UnreadCount = unreadCount;
        
        var stats = await _dashboardService.GetAdminStatsAsync();
        return View(stats);
    }

    public async Task<IActionResult> Employees()
    {
        var employees = await _employeeService.GetAllEmployeesAsync();
        return View(employees);
    }

    public async Task<IActionResult> EmployeeDetails(Guid id)
    {
        var employee = await _employeeService.GetEmployeeByIdAsync(id);
        if (employee == null)
        {
            return NotFound();
        }
        return View(employee);
    }

    public IActionResult CreateEmployee()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> CreateEmployee(CreateEmployeeViewModel model)
    {
        if (ModelState.IsValid)
        {
            var managerId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(managerId))
            {
                return RedirectToAction("Login", "Account");
            }

            try
            {
                var result = await _employeeService.CreateEmployeeAsync(model, managerId);
                TempData["Success"] = "Employee created successfully!";
                return RedirectToAction(nameof(Employees));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
            }
        }

        return View(model);
    }

    public async Task<IActionResult> EditEmployee(Guid id)
    {
        var employee = await _employeeService.GetEmployeeByIdAsync(id);
        if (employee == null)
        {
            return NotFound();
        }

        var model = new UpdateEmployeeViewModel
        {
            FirstName = employee.User?.FirstName ?? string.Empty,
            LastName = employee.User?.LastName ?? string.Empty,
            Phone = employee.Phone,
            Address = employee.Address,
            ProfilePicture = employee.ProfilePicture,
            HireDate = employee.HireDate,
            Salary = employee.Salary,
            Position = employee.Position,
            IsActive = employee.IsActive
        };

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> EditEmployee(Guid id, UpdateEmployeeViewModel model)
    {
        if (ModelState.IsValid)
        {
            var result = await _employeeService.UpdateEmployeeAsync(id, model);
            if (result)
            {
                TempData["Success"] = "Employee updated successfully!";
                return RedirectToAction(nameof(Employees));
            }
        }

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> DeleteEmployee(Guid id)
    {
        var result = await _employeeService.DeleteEmployeeAsync(id);
        if (result)
        {
            TempData["Success"] = "Employee deleted successfully!";
        }
        else
        {
            TempData["Error"] = "Failed to delete employee.";
        }

        return RedirectToAction(nameof(Employees));
    }

    [HttpPost]
    public async Task<IActionResult> UpdateEmployeeStatus(Guid id, bool isActive)
    {
        var result = await _employeeService.UpdateEmployeeStatusAsync(id, isActive);
        
        if (result)
        {
            TempData["Success"] = $"Employee status updated to {(isActive ? "Active" : "Inactive")}!";
        }
        else
        {
            TempData["Error"] = "Failed to update employee status.";
        }

        return RedirectToAction(nameof(EmployeeDetails), new { id });
    }

    public async Task<IActionResult> Notifications()
    {
        var notifications = await _notificationService.GetAdminNotificationsAsync();
        return View(notifications);
    }

    [HttpPost]
    public async Task<IActionResult> MarkNotificationRead(Guid id)
    {
        var result = await _notificationService.MarkAsReadAsync(id);
        return Json(new { success = result });
    }

    [HttpPost]
    public async Task<IActionResult> DeleteNotification(Guid id)
    {
        var result = await _notificationService.DeleteNotificationAsync(id);
        return Json(new { success = result });
    }

    [HttpPost]
    public async Task<IActionResult> ClearAllNotifications()
    {
        await _notificationService.ClearAllNotificationsAsync(null);
        return RedirectToAction(nameof(Notifications));
    }
}
