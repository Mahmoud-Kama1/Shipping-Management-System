namespace Shipy.Models.Entities;

public class CourierGovernorate
{
    public Guid CourierId { get; set; }
    public Courier Courier { get; set; } = null!;
    
    public int GovernorateId { get; set; }
    public Governorate Governorate { get; set; } = null!;
}
