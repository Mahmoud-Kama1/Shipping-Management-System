using System.ComponentModel.DataAnnotations;

namespace Shipy.Models.ViewModels;

public class CreateGovernorateViewModel
{
    [Required]
    public string Name { get; set; } = string.Empty;
    [Required]
    public string Code { get; set; } = string.Empty;
    [Required]
    public decimal DeliveryPrice { get; set; }
}

public class UpdateGovernorateViewModel : CreateGovernorateViewModel
{
}
