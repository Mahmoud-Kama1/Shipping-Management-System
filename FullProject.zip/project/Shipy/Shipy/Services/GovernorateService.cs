using Microsoft.EntityFrameworkCore;
using Shipy.Data;
using Shipy.Models.Entities;

using Shipy.Models.ViewModels;

namespace Shipy.Services;

public interface IGovernorateService
{
    Task<List<Governorate>> GetAllGovernoratesAsync();
    Task<Governorate?> GetGovernorateByIdAsync(int id);
    Task<bool> CreateGovernorateAsync(CreateGovernorateViewModel model);
    Task<bool> UpdateGovernorateAsync(int id, UpdateGovernorateViewModel model);
    Task<bool> DeleteGovernorateAsync(int id);
}

public class GovernorateService : IGovernorateService
{
    private readonly ApplicationDbContext _context;

    public GovernorateService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<List<Governorate>> GetAllGovernoratesAsync()
    {
        return await _context.Governorates
            .Where(g => g.IsActive)
            .ToListAsync();
    }

    public async Task<Governorate?> GetGovernorateByIdAsync(int id)
    {
        return await _context.Governorates.FindAsync(id);
    }

    public async Task<bool> CreateGovernorateAsync(CreateGovernorateViewModel model)
    {
        var governorate = new Governorate
        {
            Name = model.Name,
            Code = model.Code,
            DeliveryFee = model.DeliveryPrice
        };

        _context.Governorates.Add(governorate);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> UpdateGovernorateAsync(int id, UpdateGovernorateViewModel model)
    {
        var governorate = await _context.Governorates.FindAsync(id);
        if (governorate == null) return false;

        governorate.Name = model.Name;
        governorate.Code = model.Code;
        governorate.DeliveryFee = model.DeliveryPrice;

        _context.Governorates.Update(governorate);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> DeleteGovernorateAsync(int id)
    {
        var governorate = await _context.Governorates.FindAsync(id);
        if (governorate == null) return false;

        governorate.IsActive = false; // Soft delete
        _context.Governorates.Update(governorate);
        return await _context.SaveChangesAsync() > 0;
    }
}
