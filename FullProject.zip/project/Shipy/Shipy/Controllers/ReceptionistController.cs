using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Shipy.Models.Entities;
using Shipy.Models.ViewModels;
using Shipy.Services;

namespace Shipy.Controllers;

[Authorize(Roles = "Receptionist")]
public class ReceptionistController : Controller
{
    private readonly IShipmentService _shipmentService;
    private readonly IGovernorateService _governorateService;
    private readonly ICourierService _courierService;

    public ReceptionistController(IShipmentService shipmentService, IGovernorateService governorateService, ICourierService courierService)
    {
        _shipmentService = shipmentService;
        _governorateService = governorateService;
        _courierService = courierService;
    }

    public async Task<IActionResult> Index()
    {
        var shipments = await _shipmentService.GetAllShipmentsAsync();
        var dashboardData = new
        {
            TotalShipments = shipments.Count,
            PendingShipments = shipments.Count(s => s.Status == ShipmentStatus.Pending),
            InTransitShipments = shipments.Count(s => s.Status == ShipmentStatus.InTransit),
            DeliveredShipments = shipments.Count(s => s.Status == ShipmentStatus.Delivered),
            RecentShipments = shipments.Take(5).ToList()
        };

        return View(dashboardData);
    }

    public async Task<IActionResult> Shipments()
    {
        var shipments = await _shipmentService.GetAllShipmentsAsync();
        return View(shipments);
    }

    public async Task<IActionResult> Details(Guid id)
    {
        var shipment = await _shipmentService.GetShipmentByIdAsync(id);
        if (shipment == null)
        {
            return NotFound();
        }
        return View(shipment);
    }

    public async Task<IActionResult> Create()
    {
        await PopulateDropdowns();
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateShipmentViewModel model)
    {
        if (ModelState.IsValid)
        {
            model.CreatedById = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            var result = await _shipmentService.CreateShipmentAsync(model);
            
            TempData["Success"] = "Shipment created successfully!";
            return RedirectToAction(nameof(Shipments));
        }

        await PopulateDropdowns();
        return View(model);
    }

    public async Task<IActionResult> Edit(Guid id)
    {
        var shipment = await _shipmentService.GetShipmentByIdAsync(id);
        if (shipment == null)
        {
            return NotFound();
        }

        var model = new UpdateShipmentViewModel
        {
            SenderName = shipment.SenderName,
            SenderPhone = shipment.SenderPhone,
            RecipientName = shipment.RecipientName,
            RecipientPhone = shipment.RecipientPhone,
            RecipientAddress = shipment.RecipientAddress,
            Weight = shipment.Weight,
            Type = shipment.Type,
            ProductPrice = shipment.ProductPrice,
            DeliveryPrice = shipment.DeliveryPrice,
            GovernorateId = shipment.GovernorateId,
            CourierId = shipment.CourierId,
            Notes = shipment.Notes
        };

        await PopulateDropdowns();
        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(Guid id, UpdateShipmentViewModel model)
    {
        if (ModelState.IsValid)
        {
            var result = await _shipmentService.UpdateShipmentAsync(id, model);
            if (result)
            {
                TempData["Success"] = "Shipment updated successfully!";
                return RedirectToAction(nameof(Shipments));
            }
        }

        await PopulateDropdowns();
        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> UpdateStatus(Guid id, ShipmentStatus status, string? notes = null)
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        var result = await _shipmentService.UpdateShipmentStatusAsync(id, status, notes, userId);
        
        if (result)
        {
            TempData["Success"] = $"Shipment status updated to {status}!";
        }
        else
        {
            TempData["Error"] = "Failed to update shipment status.";
        }

        return RedirectToAction(nameof(Details), new { id });
    }

    private async Task PopulateDropdowns()
    {
        var governorates = await _governorateService.GetAllGovernoratesAsync();
        ViewBag.Governorates = new SelectList(governorates, "Id", "Name");

        var couriers = await _courierService.GetAvailableCouriersAsync();
        ViewBag.Couriers = new SelectList(couriers, "Id", "Name");
    }
}
