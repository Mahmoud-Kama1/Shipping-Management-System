namespace Shipy.Models.Entities;

public class Governorate
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public decimal DeliveryFee { get; set; }
    public decimal DeliveryPrice { get => DeliveryFee; set => DeliveryFee = value; } // Alias
    public bool IsActive { get; set; } = true;
    
    public ICollection<CourierGovernorate> CourierGovernorates { get; set; } = new List<CourierGovernorate>();
}
