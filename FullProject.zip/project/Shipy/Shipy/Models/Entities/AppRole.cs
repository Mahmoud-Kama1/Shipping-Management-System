using Microsoft.AspNetCore.Identity;

namespace Shipy.Models.Entities;

public static class Roles
{
    public const string Admin = "Admin";
    public const string Receptionist = "Receptionist";
    public const string Courier = "Courier";
    public const string Merchant = "Merchant";
    public const string Customer = "Customer";
}

public class AppRole : IdentityRole
{
    public string? Description { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
