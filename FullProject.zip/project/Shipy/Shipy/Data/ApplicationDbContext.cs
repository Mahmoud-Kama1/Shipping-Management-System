using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Shipy.Models.Entities;

namespace Shipy.Data;

public class ApplicationDbContext : IdentityDbContext<User, AppRole, string>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<Shipment> Shipments { get; set; }
    public DbSet<Courier> Couriers { get; set; }
    public DbSet<Governorate> Governorates { get; set; }
    public DbSet<CourierGovernorate> CourierGovernorates { get; set; }
    public DbSet<ShipmentStatusHistory> ShipmentStatusHistories { get; set; }
    public DbSet<Notification> Notifications { get; set; }
    public DbSet<RefreshToken> RefreshTokens { get; set; }
    public DbSet<Employee> Employees { get; set; }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        // Courier - Governorate (Many-to-Many)
        builder.Entity<CourierGovernorate>()
            .HasKey(cg => new { cg.CourierId, cg.GovernorateId });

        builder.Entity<CourierGovernorate>()
            .HasOne(cg => cg.Courier)
            .WithMany(c => c.CourierGovernorates)
            .HasForeignKey(cg => cg.CourierId);

        builder.Entity<CourierGovernorate>()
            .HasOne(cg => cg.Governorate)
            .WithMany(g => g.CourierGovernorates)
            .HasForeignKey(cg => cg.GovernorateId);

        // Shipment - Courier (One-to-Many)
        builder.Entity<Shipment>()
            .HasOne(s => s.Courier)
            .WithMany(c => c.Shipments)
            .HasForeignKey(s => s.CourierId)
            .OnDelete(DeleteBehavior.Restrict);

        // Shipment - Governorate (One-to-Many)
        builder.Entity<Shipment>()
            .HasOne(s => s.Governorate)
            .WithMany()
            .HasForeignKey(s => s.GovernorateId)
            .OnDelete(DeleteBehavior.Restrict);

        // Shipment - User (CreatedBy)
        builder.Entity<Shipment>()
            .HasOne(s => s.CreatedBy)
            .WithMany()
            .HasForeignKey(s => s.CreatedById)
            .OnDelete(DeleteBehavior.Restrict);
            
        // ShipmentStatusHistory - Shipment
        builder.Entity<ShipmentStatusHistory>()
            .HasOne(h => h.Shipment)
            .WithMany(s => s.StatusHistory)
            .HasForeignKey(h => h.ShipmentId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
