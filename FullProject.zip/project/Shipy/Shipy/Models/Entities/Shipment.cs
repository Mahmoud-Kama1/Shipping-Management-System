namespace Shipy.Models.Entities;

public class Shipment
{
    public Guid Id { get; set; }
    public string SenderName { get; set; } = string.Empty;
    public string SenderPhone { get; set; } = string.Empty;
    public string RecipientName { get; set; } = string.Empty;
    public string RecipientPhone { get; set; } = string.Empty;
    public string RecipientAddress { get; set; } = string.Empty;
    
    public double Weight { get; set; }
    public string Type { get; set; } = string.Empty;
    public decimal ProductPrice { get; set; }
    public decimal DeliveryPrice { get; set; }
    
    public int GovernorateId { get; set; }
    public Governorate Governorate { get; set; } = null!;
    
    public Guid? CourierId { get; set; }
    public Courier? Courier { get; set; }
    
    public string? Notes { get; set; }
    public ShipmentStatus Status { get; set; } = ShipmentStatus.Pending;
    
    public string CreatedById { get; set; } = string.Empty;
    public User CreatedBy { get; set; } = null!;
    
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    
    public ICollection<ShipmentStatusHistory> StatusHistory { get; set; } = new List<ShipmentStatusHistory>();
}
