// Utilities and shared navbar for all authenticated pages
;(function(){
  const LS_USERS = 'courier_system_users';
  const LS_PROFILES = 'courier_system_profiles';
  const LS_NOTIFICATIONS = 'courier_system_notifications_v2'; // v2: per-user readBy
  const LS_SESSION = 'courier_system_session';
  const LS_SCHEMA_VERSION = 'courier_schema_version';
  const SHIP_KEY_UNIFIED = 'shipments_u1';
  const LEGACY_KEYS = ['shipments_v2','shipments'];

  function getLS(key, fallback){
    try { const v = JSON.parse(localStorage.getItem(key)); return (v==null?fallback:v); } catch{ return fallback; }
  }
  const _debounceTimers = {};
  function setLS(key, value){ localStorage.setItem(key, JSON.stringify(value)); }
  function setLSDebounced(key, value, delay=250){
    clearTimeout(_debounceTimers[key]);
    _debounceTimers[key] = setTimeout(()=> setLS(key, value), delay);
  }

  function getSession(){ return getLS(LS_SESSION, null); }

  function goToIndex(){
    const p = window.location.pathname;
    const target = p.includes('/merchant_ui/Pages/') ? '../../index.html' : '../index.html';
    window.location.href = target;
  }

  function requireAuth(){
    const s = getSession();
    if(!s || !s.email){ goToIndex(); }
    return s;
  }

  // Notifications v2: { id, type, message, actor{email,role}, timestamp, readBy{[email]:true} }
  function ensureNotifications(){
    const arr = getLS(LS_NOTIFICATIONS, []);
    if(!Array.isArray(arr)) { setLS(LS_NOTIFICATIONS, []); return []; }
    // migrate v1 isRead -> readBy for current user
    const s = getSession();
    let migrated = false;
    const v2 = arr.map(n=>{
      if(n && n.isRead !== undefined){
        migrated = true;
        const readBy = {};
        if(n.isRead && s && s.email) readBy[s.email]=true;
        const { isRead, ...rest } = n;
        return { ...rest, readBy };
      }
      return n;
    });
    if(migrated) setLS(LS_NOTIFICATIONS, v2);
    return v2;
  }

  function unreadCount(){
    const list = ensureNotifications();
    const s = getSession();
    const me = s?.email;
    return list.filter(n => n && (!n.readBy || !n.readBy[me])).length;
  }

  function markAllRead(){
    const s = getSession();
    if(!s) return;
    const list = ensureNotifications().map(n => ({...n, readBy: { ...(n.readBy||{}), [s.email]: true }}));
    setLSDebounced(LS_NOTIFICATIONS, list);
  }

  function createNotification(message, type){
    const list = ensureNotifications();
    const s = getSession();
    list.unshift({ id: Date.now(), message, type, actor: s?{ email:s.email, role:s.role }:null, timestamp: new Date().toLocaleString(), readBy:{} });
    setLSDebounced(LS_NOTIFICATIONS, list);
  }

  // Simple event bus for cross-page patterns (emit/on/off)
  const Events = (function(){
    const handlers = {};
    return {
      on(evt, fn){ (handlers[evt] = handlers[evt] || []).push(fn); },
      off(evt, fn){ const a = handlers[evt]||[]; const i=a.indexOf(fn); if(i>-1) a.splice(i,1); },
      emit(evt, payload){ (handlers[evt]||[]).forEach(f=>{ try{ f(payload); }catch(e){} }); }
    };
  })();

  // Unified store and migrations
  function uid(prefix){ return (prefix||'ID-') + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2,6).toUpperCase(); }
  function getUnifiedShipments(){ return getLS(SHIP_KEY_UNIFIED, []); }
  function saveUnifiedShipments(list){ setLSDebounced(SHIP_KEY_UNIFIED, Array.isArray(list)?list:[]); }
  function migrateIfNeeded(){
    const ver = getLS(LS_SCHEMA_VERSION, 0);
    if(ver >= 1) return; // already migrated
    let merged = getUnifiedShipments();
    if(!Array.isArray(merged)) merged = [];
    LEGACY_KEYS.forEach(k=>{
      const src = getLS(k, []);
      if(Array.isArray(src)){
        src.forEach(s=>{
          if(!s) return;
          // Map legacy to unified schema
          const unified = {
            id: s.id || uid('#'),
            ownerEmail: s.ownerEmail || s.email || null,
            createdBy: s.createdBy || null,
            recipient: {
              name: s.receiver || s.recipientName || '',
              phone: s.phone || s.recipientPhone || '',
              address: s.address || s.recipientAddress || ''
            },
            recipientGovernorate: s.city || s.governorate || '',
            assignedCourier: s.assignedCourier || '',
            pricing: {
              product: Number(s.productPrice || s.cod || 0),
              delivery: Number(s.deliveryPrice || 0),
              total: Number(s.total || 0)
            },
            status: s.status || 'Pending',
            history: s.history || [],
            createdAt: s.createdAt || Date.now(),
            updatedAt: Date.now()
          };
          merged.unshift(unified);
        });
      }
    });
    if(merged.length>0){ setLS(SHIP_KEY_UNIFIED, merged); setLS(LS_SCHEMA_VERSION, 1); }
  }
  migrateIfNeeded();

  function getProfiles(){
    const p = getLS(LS_PROFILES, {});
    return (Array.isArray(p) ? {} : (p || {}));
  }
  function saveProfiles(p){ setLS(LS_PROFILES, p); }

  function getUsers(){ return getLS(LS_USERS, []); }
  function saveUsers(u){ setLS(LS_USERS, Array.isArray(u)?u:[]); }

  function injectNavbar(options){
    const session = getSession();
    if(!session) return; // already redirected by requireAuth if used
    const role = session.role;
    const name = session.name || session.email;

    const container = document.createElement('div');
    container.style.cssText = 'position:sticky;top:0;z-index:9999;background:#0b1b6a;color:#fff;border-bottom:1px solid #0d207e;';
    container.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 16px;width:100%;flex-wrap:wrap;box-sizing:border-box;">
        <div style="display:flex;align-items:center;gap:10px;">
          <div style="width:28px;height:28px;border-radius:6px;background:#fff"></div>
          <div style="font-weight:800;letter-spacing:0.3px">CourierHub</div>
        </div>
        <div style="display:flex;align-items:center;gap:12px;">
          <button id="nav-notify" style="position:relative;background:transparent;border:1px solid rgba(255,255,255,0.25);color:#fff;padding:6px 10px;border-radius:8px;cursor:pointer">Notifications
            <span id="nav-notify-badge" style="display:none;position:absolute;top:-6px;right:-6px;background:#ff5252;color:#fff;border-radius:999px;padding:2px 6px;font-size:11px;font-weight:700"></span>
          </button>
          ${role==='admin' ? `<button id="nav-manage-employees" style="background:#1e2aa6;border:none;color:#fff;padding:6px 10px;border-radius:8px;cursor:pointer">Manage Employees</button>` : ''}
          ${role==='merchant' ? `<button id="nav-edit-profile" style="background:#1e2aa6;border:none;color:#fff;padding:6px 10px;border-radius:8px;cursor:pointer">My Profile</button>` : ''}
          <div style="display:flex;align-items:center;gap:8px;background:#1e2aa6;padding:6px 10px;border-radius:20px">
            <div style="width:24px;height:24px;border-radius:50%;background:#fff"></div>
            <div style="font-weight:700">${name} — ${role}</div>
          </div>
          <button id="nav-logout" style="background:#ff6b6b;border:none;color:#fff;padding:6px 10px;border-radius:8px;cursor:pointer">Logout</button>
        </div>
      </div>
    `;
    document.body.insertBefore(container, document.body.firstChild);

    const badge = container.querySelector('#nav-notify-badge');
    const btnNotify = container.querySelector('#nav-notify');
    const btnLogout = container.querySelector('#nav-logout');
    const btnManage = container.querySelector('#nav-manage-employees');
    const btnProfile = container.querySelector('#nav-edit-profile');

    function refreshBadge(){
      const c = unreadCount();
      if(c>0){ badge.style.display='inline-block'; badge.textContent = c; }
      else { badge.style.display='none'; }
    }
    refreshBadge();

    btnNotify.addEventListener('click', function(){
      const list = ensureNotifications();
      const dialog = document.createElement('div');
      dialog.style.cssText = 'position:fixed;right:16px;top:56px;width:360px;max-height:60vh;overflow:auto;background:#fff;color:#111;border-radius:10px;box-shadow:0 10px 30px rgba(0,0,0,0.18);z-index:10000;padding:8px';
      dialog.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:space-between;padding:6px 8px;border-bottom:1px solid #eee">
          <strong>Notifications</strong>
          <button id="notif-mark-read" style="background:#0d6efd;border:none;color:#fff;padding:6px 10px;border-radius:6px;cursor:pointer">Mark all read</button>
        </div>
        <div>
          ${list.length===0?'<div style="padding:10px;color:#666">No notifications</div>': list.map(n=>{
            const s = getSession();
            const read = !!(n.readBy && s && n.readBy[s.email]);
            const actor = n.actor ? ` — ${n.actor.role||''}` : '';
            return `
            <div style="padding:8px;border-bottom:1px solid #f1f1f1;${read?'background:#fafafa':'background:#eef3ff'}">
              <div style="font-size:13px;font-weight:700">${(n.type||'UPDATE')}${actor}</div>
              <div style="font-size:13px">${n.message}</div>
              <div style="font-size:11px;color:#666">${n.timestamp||''}</div>
            </div>`;
          }).join('')}
        </div>
      `;
      document.body.appendChild(dialog);
      dialog.querySelector('#notif-mark-read')?.addEventListener('click', ()=>{ markAllRead(); refreshBadge(); document.body.removeChild(dialog); });
      function closeOnOutside(e){ if(!dialog.contains(e.target)){ document.body.removeChild(dialog); document.removeEventListener('click', closeOnOutside); } }
      setTimeout(()=> document.addEventListener('click', closeOnOutside), 0);
    });

    btnLogout.addEventListener('click', function(){
      localStorage.removeItem(LS_SESSION);
      goToIndex();
    });

    if(btnManage){
      btnManage.addEventListener('click', function(){
        const wrapper = document.createElement('div');
        wrapper.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,0.35);display:flex;align-items:center;justify-content:center;z-index:10001;padding:16px';
        const users = getUsers();
        const profiles = getProfiles();
        wrapper.innerHTML = `
          <div style="background:#fff;border-radius:12px;max-width:900px;width:100%;padding:16px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
              <h3 style="margin:0">Manage Employees</h3>
              <button id="emp-close" style="background:transparent;border:1px solid #eee;padding:6px 10px;border-radius:6px;cursor:pointer">Exit</button>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
              <div>
                <h4 style="margin:6px 0">Accounts</h4>
                <div id="emp-users" style="border:1px solid #eee;border-radius:8px;max-height:50vh;overflow:auto"></div>
                <button id="emp-add" style="margin-top:8px;background:#0d6efd;border:none;color:#fff;padding:8px 10px;border-radius:6px;cursor:pointer">Add Employee</button>
              </div>
              <div>
                <h4 style="margin:6px 0">Personal Data</h4>
                <div id="emp-profile" style="border:1px solid #eee;border-radius:8px;padding:8px;min-height:150px">Choose an account from the list to see personal data.</div>
              </div>
            </div>
            <div style="display:flex;justify-content:flex-end;margin-top:12px">
              <button id="emp-exit-bottom" style="background:transparent;border:1px solid #eee;padding:8px 12px;border-radius:8px;cursor:pointer">Exit</button>
            </div>
          </div>
        `;
        document.body.appendChild(wrapper);

        function openUserForm(initial, onSave){
          const modal = document.createElement('div');
          modal.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,0.35);display:flex;align-items:center;justify-content:center;z-index:10002;padding:16px';
          const u = initial||{ name:'', email:'', password:'', role:'receptionist' };
          const existingProfiles = getProfiles() || {};
          const existingProfile = (u.email && existingProfiles[u.email]) ? existingProfiles[u.email] : { phone:'', address:'' };
          modal.innerHTML = `
            <div style="background:#fff;border-radius:12px;max-width:520px;width:100%;padding:16px">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
                <h3 style="margin:0">${initial?'Edit':'Add'} Employee</h3>
                <button id="user-exit" style="background:transparent;border:1px solid #eee;padding:6px 10px;border-radius:6px;cursor:pointer">Exit</button>
              </div>
              <label>Name</label>
              <input id="f-name" style="width:100%;padding:8px;border:1px solid #eee;border-radius:8px" value="${u.name||''}">
              <label style="margin-top:8px;display:block">Email</label>
              <input id="f-email" style="width:100%;padding:8px;border:1px solid #eee;border-radius:8px" value="${u.email||''}">
              <label style="margin-top:8px;display:block">Password</label>
              <input id="f-pass" type="password" style="width:100%;padding:8px;border:1px solid #eee;border-radius:8px" value="${u.password||''}">
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">
                <div>
                  <label>Phone</label>
                  <input id="f-phone" style="width:100%;padding:8px;border:1px solid #eee;border-radius:8px" value="${existingProfile.phone||''}">
                </div>
                <div>
                  <label>Address</label>
                  <input id="f-address" style="width:100%;padding:8px;border:1px solid #eee;border-radius:8px" value="${existingProfile.address||''}">
                </div>
              </div>
              <label style="margin-top:8px;display:block">Role</label>
              <select id="f-role" style="width:100%;padding:8px;border:1px solid #eee;border-radius:8px">
                <option value="admin" ${u.role==='admin'?'selected':''}>Admin</option>
                <option value="receptionist" ${u.role==='receptionist'?'selected':''}>Receptionist</option>
                <option value="courier" ${u.role==='courier'?'selected':''}>Courier</option>
                <option value="merchant" ${u.role==='merchant'?'selected':''}>Merchant</option>
              </select>
              <div style="margin-top:12px;display:flex;justify-content:flex-end;gap:8px">
                <button id="user-cancel" style="background:#ccc;border:none;padding:8px 12px;border-radius:8px;cursor:pointer">Cancel</button>
                <button id="user-save" style="background:#0d6efd;border:none;color:#fff;padding:8px 12px;border-radius:8px;cursor:pointer">Save</button>
              </div>
            </div>
          `;
          document.body.appendChild(modal);
          function close(){ document.body.removeChild(modal); }
          modal.querySelector('#user-exit').addEventListener('click', close);
          modal.querySelector('#user-cancel').addEventListener('click', close);
          modal.addEventListener('click', (e)=>{ if(e.target===modal) close(); });
          modal.querySelector('#user-save').addEventListener('click', ()=>{
            const val = {
              name: (modal.querySelector('#f-name').value||'').trim(),
              email: (modal.querySelector('#f-email').value||'').trim(),
              password: (modal.querySelector('#f-pass').value||'').trim(),
              role: modal.querySelector('#f-role').value,
              phone: (modal.querySelector('#f-phone').value||'').trim(),
              address: (modal.querySelector('#f-address').value||'').trim()
            };
            onSave(val, close);
          });
        }

        function renderUsers(){
          const box = wrapper.querySelector('#emp-users');
          const us = getUsers();
          box.innerHTML = us.map((u,i)=>`
            <div data-i="${i}" class="emp-row" style="display:flex;align-items:center;justify-content:space-between;padding:8px;border-bottom:1px solid #f3f3f3;cursor:pointer">
              <div>
                <div style="font-weight:700">${u.name||u.email}</div>
                <div style="font-size:12px;color:#666">${u.email} — ${u.role}</div>
              </div>
              <div style="display:flex;gap:6px">
                <button class="emp-edit" style="background:#1e2aa6;border:none;color:#fff;padding:6px 10px;border-radius:6px;cursor:pointer">Edit</button>
                <button class="emp-del" style="background:#ff6b6b;border:none;color:#fff;padding:6px 10px;border-radius:6px;cursor:pointer">Delete</button>
              </div>
            </div>
          `).join('');
          box.querySelectorAll('.emp-edit').forEach((btn,idx)=> btn.addEventListener('click', ()=> editUser(idx)) );
          box.querySelectorAll('.emp-del').forEach((btn,idx)=> btn.addEventListener('click', ()=> delUser(idx)) );
          box.querySelectorAll('.emp-row').forEach((row)=>{
            row.addEventListener('click', ()=>{
              const i = Number(row.getAttribute('data-i'));
              selectUser(i);
            });
          });
        }

        function selectUser(idx){
          const us = getUsers();
          const u = us[idx];
          const pr = getProfiles();
          const p = pr[u.email] || { name: u.name||'', phone:'', address:'' };
          const panel = wrapper.querySelector('#emp-profile');
          panel.innerHTML = `
            <div><b>Name:</b> ${p.name||u.name||'-'}</div>
            <div><b>Email:</b> ${u.email}</div>
            <div><b>Phone:</b> ${p.phone||'-'}</div>
            <div><b>Address:</b> ${p.address||'-'}</div>
            <div style="margin-top:8px;font-size:12px;color:#666">Tip: Use Edit to update account or profile.</div>
          `;
          wrapper.querySelectorAll('.emp-row').forEach(r=> r.style.background='');
          const row = wrapper.querySelector(`.emp-row[data-i="${idx}"]`);
          if(row) row.style.background = '#f6f8ff';
        }

        function editUser(idx){
          const us = getUsers();
          const u = us[idx];
          openUserForm(u, (val, close)=>{
            if(!val.email){ alert('Email is required'); return; }
            const oldEmail = u.email;
            us[idx] = { email:val.email, password:val.password||'', role:val.role, name:val.name||val.email };
            saveUsers(us);
            const pr = getProfiles();
            if(oldEmail && oldEmail !== val.email && pr[oldEmail]){
              pr[val.email] = pr[oldEmail];
              delete pr[oldEmail];
            }
            pr[val.email] = { name: val.name||'', phone: val.phone||'', address: val.address||'' };
            saveProfiles(pr);
            createNotification(`Employee updated: ${val.name||val.email}`, 'EMPLOYEE');
            renderUsers();
            close();
          });
        }
        function delUser(idx){
          const us = getUsers();
          const u = us[idx];
          if(!confirm('Delete employee '+(u.email)+'?')) return;
          us.splice(idx,1);
          saveUsers(us);
          createNotification(`Employee deleted: ${u.email}`, 'EMPLOYEE');
          renderUsers();
          wrapper.querySelector('#emp-profile').textContent = 'Select a user';
        }

        wrapper.querySelector('#emp-add').addEventListener('click', ()=>{
          openUserForm(null, (val, close)=>{
            const us = getUsers();
            if(!val.email){ alert('Email is required'); return; }
            if(us.some(x=>x.email===val.email)) { alert('Email exists'); return; }
            us.push({ email:val.email, password:val.password||'', role:val.role, name:val.name||val.email });
            saveUsers(us);
            const pr = getProfiles(); pr[val.email] = { name:val.name||'', phone:val.phone||'', address:val.address||'' }; saveProfiles(pr);
            createNotification(`New employee: ${val.name||val.email}`, 'EMPLOYEE');
            renderUsers();
            close();
          });
        });

        function closeManage(){ document.body.removeChild(wrapper); }
        wrapper.addEventListener('click', (e)=>{ if(e.target===wrapper) closeManage(); });
        wrapper.querySelector('#emp-close').addEventListener('click', closeManage);
        wrapper.querySelector('#emp-exit-bottom').addEventListener('click', closeManage);
        renderUsers();
      });
    }

    if(btnProfile){
      btnProfile.addEventListener('click', function(){
        const s = getSession();
        const profiles = getProfiles();
        const me = profiles[s.email] || { name: s.name||'', phone:'', address:'' };
        const wrap = document.createElement('div');
        wrap.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,0.35);display:flex;align-items:center;justify-content:center;z-index:10001;padding:16px';
        wrap.innerHTML = `
          <div style="background:#fff;border-radius:12px;max-width:520px;width:100%;padding:16px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
              <h3 style="margin:0">My Profile</h3>
              <button id="p-close" style="background:transparent;border:1px solid #eee;padding:6px 10px;border-radius:6px;cursor:pointer">Close</button>
            </div>
            <label>Name</label>
            <input id="p-name" style="width:100%;padding:8px;border:1px solid #eee;border-radius:8px" value="${me.name||''}">
            <label style="margin-top:8px;display:block">Phone</label>
            <input id="p-phone" style="width:100%;padding:8px;border:1px solid #eee;border-radius:8px" value="${me.phone||''}">
            <label style="margin-top:8px;display:block">Address</label>
            <textarea id="p-address" style="width:100%;min-height:80px;padding:8px;border:1px solid #eee;border-radius:8px">${me.address||''}</textarea>
            <div style="margin-top:12px;display:flex;justify-content:flex-end;gap:8px">
              <button id="p-save" style="background:#0d6efd;border:none;color:#fff;padding:8px 12px;border-radius:8px;cursor:pointer">Save</button>
            </div>
          </div>
        `;
        document.body.appendChild(wrap);
        wrap.querySelector('#p-close').addEventListener('click', ()=> document.body.removeChild(wrap));
        wrap.querySelector('#p-save').addEventListener('click', ()=>{
          const pr = getProfiles();
          pr[s.email] = {
            name: (wrap.querySelector('#p-name').value||'').trim(),
            phone: (wrap.querySelector('#p-phone').value||'').trim(),
            address: (wrap.querySelector('#p-address').value||'').trim()
          };
          saveProfiles(pr);
          createNotification(`Profile updated: ${s.email}`, 'PROFILE');
          alert('Saved');
          document.body.removeChild(wrap);
        });
      });
    }

    return container;
  }

  // Expose to window
  window.CourierCommon = {
    requireAuth,
    injectNavbar,
    getSession,
    createNotification,
    getLS,
    setLS,
    // Permissions helper
    can(role, action){
      const rules = {
        'manage_employees': ['admin'],
        'create_shipment': ['merchant','receptionist','admin'],
        'edit_shipment': ['receptionist','admin'],
        'update_status': ['courier','admin'],
        'view_admin': ['admin'],
        'view_receptionist': ['receptionist','admin'],
        'view_courier': ['courier','admin'],
        'view_merchant': ['merchant','admin']
      };
      const allow = rules[action] || [];
      return allow.includes(role);
    },
    // Simple validators
    validators: {
      required(v){ return (v!=null) && String(v).trim().length>0; },
      positiveNumber(v){ const n=Number(v); return !isNaN(n) && n>=0; },
      phone(v){ return /^[0-9+()\-\s]{7,20}$/.test(String(v||'')); }
    }
  };
})();


