using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shipy.Models.ViewModels;
using Shipy.Services;

namespace Shipy.Controllers;

[Authorize(Policy = "AdminOnly")]
public class GovernorateController : Controller
{
    private readonly IGovernorateService _governorateService;

    public GovernorateController(IGovernorateService governorateService)
    {
        _governorateService = governorateService;
    }

    public async Task<IActionResult> Index()
    {
        var governorates = await _governorateService.GetAllGovernoratesAsync();
        return View(governorates);
    }

    public async Task<IActionResult> Details(int id)
    {
        var governorate = await _governorateService.GetGovernorateByIdAsync(id);
        if (governorate == null)
        {
            return NotFound();
        }
        return View(governorate);
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateGovernorateViewModel model)
    {
        if (ModelState.IsValid)
        {
            var result = await _governorateService.CreateGovernorateAsync(model);
            
            TempData["Success"] = "Governorate created successfully!";
            return RedirectToAction(nameof(Index));
        }

        return View(model);
    }

    public async Task<IActionResult> Edit(int id)
    {
        var governorate = await _governorateService.GetGovernorateByIdAsync(id);
        if (governorate == null)
        {
            return NotFound();
        }

        var model = new UpdateGovernorateViewModel
        {
            Name = governorate.Name,
            Code = governorate.Code,
            DeliveryPrice = governorate.DeliveryPrice
        };

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int id, UpdateGovernorateViewModel model)
    {
        if (ModelState.IsValid)
        {
            var result = await _governorateService.UpdateGovernorateAsync(id, model);
            if (result)
            {
                TempData["Success"] = "Governorate updated successfully!";
                return RedirectToAction(nameof(Index));
            }
        }

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await _governorateService.DeleteGovernorateAsync(id);
        if (result)
        {
            TempData["Success"] = "Governorate deleted successfully!";
        }
        else
        {
            TempData["Error"] = "Failed to delete governorate.";
        }

        return RedirectToAction(nameof(Index));
    }
}
