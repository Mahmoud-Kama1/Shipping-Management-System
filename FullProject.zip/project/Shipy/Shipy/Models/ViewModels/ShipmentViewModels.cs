using System.ComponentModel.DataAnnotations;
using Shipy.Models.Entities;

namespace Shipy.Models.ViewModels;

public class CreateShipmentViewModel
{
    [Required]
    public string SenderName { get; set; } = string.Empty;
    [Required]
    public string SenderPhone { get; set; } = string.Empty;
    [Required]
    public string RecipientName { get; set; } = string.Empty;
    [Required]
    public string RecipientPhone { get; set; } = string.Empty;
    [Required]
    public string RecipientAddress { get; set; } = string.Empty;
    
    [Required]
    public double Weight { get; set; }
    [Required]
    public string Type { get; set; } = string.Empty;
    
    public decimal ProductPrice { get; set; }
    
    [Required]
    public int GovernorateId { get; set; }
    
    public Guid? CourierId { get; set; }
    public string? Notes { get; set; }
    
    public string? CreatedById { get; set; }
}

public class UpdateShipmentViewModel : CreateShipmentViewModel
{
    public decimal DeliveryPrice { get; set; }
}
