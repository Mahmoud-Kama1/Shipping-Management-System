using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Shipy.Data;
using Shipy.Models.Entities;
using Shipy.Models.ViewModels;

namespace Shipy.Services;

public interface IDashboardService
{
    Task<object> GetAdminStatsAsync();
    Task<object> GetDashboardDataAsync();
}

public class DashboardService : IDashboardService
{
    private readonly ApplicationDbContext _context;

    public DashboardService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<object> GetAdminStatsAsync()
    {
        var totalOrders = await _context.Shipments.CountAsync();
        var inTransit = await _context.Shipments.CountAsync(s => s.Status == ShipmentStatus.InTransit);
        var delivered = await _context.Shipments.CountAsync(s => s.Status == ShipmentStatus.Delivered);
        var cancelled = await _context.Shipments.CountAsync(s => s.Status == ShipmentStatus.Cancelled);
        
        // Get recent shipments
        var recentShipments = await _context.Shipments
            .Include(s => s.Courier)
            .OrderByDescending(s => s.CreatedAt)
            .Take(10)
            .Select(s => new 
            {
                s.Id,
                s.SenderName,
                s.Status,
                s.RecipientAddress
            })
            .ToListAsync();

        return new
        {
            TotalOrders = totalOrders,
            InTransit = inTransit,
            Delivered = delivered,
            Cancelled = cancelled,
            RecentShipments = recentShipments
        };
    }

    public async Task<object> GetDashboardDataAsync()
    {
        // General dashboard data if needed
        return await GetAdminStatsAsync();
    }
}

public interface IMerchantService
{
    Task<object> GetMerchantStatsAsync(string userId);
    Task<object> GetMerchantDashboardAsync(string userId);
    Task<List<Shipment>> GetMerchantShipmentsAsync(string userId);
    Task<bool> CreateMerchantShipmentAsync(CreateShipmentViewModel model, string userId);
    Task<bool> UpdateMerchantShipmentAsync(Guid id, UpdateShipmentViewModel model, string userId);
    Task<bool> DeleteMerchantShipmentAsync(Guid id, string userId);
}

public class MerchantService : IMerchantService
{
    private readonly ApplicationDbContext _context;

    public MerchantService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<object> GetMerchantStatsAsync(string userId)
    {
        return await GetMerchantDashboardAsync(userId);
    }

    public async Task<object> GetMerchantDashboardAsync(string userId)
    {
        var shipments = await _context.Shipments
            .Where(s => s.CreatedById == userId)
            .OrderByDescending(s => s.CreatedAt)
            .ToListAsync();

        return new MerchantDashboardViewModel
        {
            Shipments = shipments,
            TotalShipments = shipments.Count,
            InTransit = shipments.Count(s => s.Status == ShipmentStatus.InTransit),
            Delivered = shipments.Count(s => s.Status == ShipmentStatus.Delivered),
            Pending = shipments.Count(s => s.Status == ShipmentStatus.Pending)
        };
    }

    public async Task<List<Shipment>> GetMerchantShipmentsAsync(string userId)
    {
        return await _context.Shipments
            .Where(s => s.CreatedById == userId)
            .OrderByDescending(s => s.CreatedAt)
            .ToListAsync();
    }

    public async Task<bool> CreateMerchantShipmentAsync(CreateShipmentViewModel model, string userId)
    {
        var governorate = await _context.Governorates.FindAsync(model.GovernorateId);
        var deliveryFee = governorate?.DeliveryFee ?? 0;

        var shipment = new Shipment
        {
            SenderName = model.SenderName,
            SenderPhone = model.SenderPhone,
            RecipientName = model.RecipientName,
            RecipientPhone = model.RecipientPhone,
            RecipientAddress = model.RecipientAddress,
            GovernorateId = model.GovernorateId,
            CourierId = null, // Merchants cannot assign couriers
            Type = model.Type,
            Weight = model.Weight,
            ProductPrice = model.ProductPrice,
            DeliveryPrice = deliveryFee,
            Notes = model.Notes,
            Status = ShipmentStatus.Pending,
            CreatedById = userId,
            CreatedAt = DateTime.UtcNow
        };

        _context.Shipments.Add(shipment);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> UpdateMerchantShipmentAsync(Guid id, UpdateShipmentViewModel model, string userId)
    {
        var shipment = await _context.Shipments.FirstOrDefaultAsync(s => s.Id == id && s.CreatedById == userId);
        if (shipment == null) return false;

        // Recalculate delivery fee if governorate changes
        if (shipment.GovernorateId != model.GovernorateId)
        {
            var governorate = await _context.Governorates.FindAsync(model.GovernorateId);
            shipment.DeliveryPrice = governorate?.DeliveryFee ?? shipment.DeliveryPrice;
        }

        shipment.SenderName = model.SenderName;
        shipment.SenderPhone = model.SenderPhone;
        shipment.RecipientName = model.RecipientName;
        shipment.RecipientPhone = model.RecipientPhone;
        shipment.RecipientAddress = model.RecipientAddress;
        shipment.GovernorateId = model.GovernorateId;
        // CourierId is not updated by Merchant
        shipment.Type = model.Type;
        shipment.Weight = model.Weight;
        shipment.ProductPrice = model.ProductPrice;
        shipment.Notes = model.Notes;
        shipment.UpdatedAt = DateTime.UtcNow;

        _context.Shipments.Update(shipment);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> DeleteMerchantShipmentAsync(Guid id, string userId)
    {
        var shipment = await _context.Shipments.FirstOrDefaultAsync(s => s.Id == id && s.CreatedById == userId);
        if (shipment == null) return false;

        _context.Shipments.Remove(shipment);
        return await _context.SaveChangesAsync() > 0;
    }
}

public interface ITrackingService
{
    Task<TrackingViewModel> TrackShipmentAsync(string shipmentNumber);
    Task<List<TrackingViewModel>> GetTrackingHistoryAsync(string userId);
}

public class TrackingService : ITrackingService
{
    public async Task<TrackingViewModel> TrackShipmentAsync(string shipmentNumber)
    {
        return new TrackingViewModel { IsFound = false, Message = "Shipment not found" };
    }

    public async Task<List<TrackingViewModel>> GetTrackingHistoryAsync(string userId)
    {
        return new List<TrackingViewModel>();
    }
}

public interface INotificationService
{
    Task SendNotificationAsync(string userId, string title, string message);
    Task<List<Notification>> GetUserNotificationsAsync(string userId);
    Task<List<Notification>> GetAdminNotificationsAsync();
    Task<int> GetUnreadCountAsync(string? userId);
    Task<bool> MarkAsReadAsync(Guid id);
    Task<bool> DeleteNotificationAsync(Guid id);
    Task ClearAllNotificationsAsync(string? userId);
}

public class NotificationService : INotificationService
{
    private readonly ApplicationDbContext _context;

    public NotificationService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task SendNotificationAsync(string userId, string title, string message)
    {
        var notification = new Notification
        {
            UserId = userId,
            Title = title,
            Message = message,
            CreatedAt = DateTime.UtcNow,
            IsRead = false
        };

        _context.Notifications.Add(notification);
        await _context.SaveChangesAsync();
    }

    public async Task<List<Notification>> GetUserNotificationsAsync(string userId)
    {
        return await _context.Notifications
            .Where(n => n.UserId == userId)
            .OrderByDescending(n => n.CreatedAt)
            .ToListAsync();
    }

    public async Task<List<Notification>> GetAdminNotificationsAsync()
    {
        return await _context.Notifications
            .OrderByDescending(n => n.CreatedAt)
            .Take(50)
            .ToListAsync();
    }

    public async Task<int> GetUnreadCountAsync(string? userId)
    {
        var query = _context.Notifications.AsQueryable();
        if (!string.IsNullOrEmpty(userId))
        {
            query = query.Where(n => n.UserId == userId);
        }
        return await query.CountAsync(n => !n.IsRead);
    }

    public async Task<bool> MarkAsReadAsync(Guid id)
    {
        var notification = await _context.Notifications.FindAsync(id);
        if (notification == null) return false;

        notification.IsRead = true;
        _context.Notifications.Update(notification);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> DeleteNotificationAsync(Guid id)
    {
        var notification = await _context.Notifications.FindAsync(id);
        if (notification == null) return false;

        _context.Notifications.Remove(notification);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task ClearAllNotificationsAsync(string? userId)
    {
        var query = _context.Notifications.AsQueryable();
        if (!string.IsNullOrEmpty(userId))
        {
            query = query.Where(n => n.UserId == userId);
        }
        
        var notifications = await query.ToListAsync();
        _context.Notifications.RemoveRange(notifications);
        await _context.SaveChangesAsync();
    }
}

public interface IEmployeeService
{
    Task<List<Employee>> GetAllEmployeesAsync();
    Task<Employee?> GetEmployeeByIdAsync(Guid id);
    Task<Employee?> GetEmployeeByUserIdAsync(string userId);
    Task<bool> CreateEmployeeAsync(CreateEmployeeViewModel model, string managerId);
    Task<bool> UpdateEmployeeAsync(Guid id, UpdateEmployeeViewModel model);
    Task<bool> DeleteEmployeeAsync(Guid id);
    Task<bool> UpdateEmployeeStatusAsync(Guid id, bool isActive);
}

public class EmployeeService : IEmployeeService
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<User> _userManager;

    public EmployeeService(ApplicationDbContext context, UserManager<User> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    public async Task<List<Employee>> GetAllEmployeesAsync()
    {
        return await _context.Employees
            .Include(e => e.User)
            .ToListAsync();
    }

    public async Task<Employee?> GetEmployeeByIdAsync(Guid id)
    {
        return await _context.Employees
            .Include(e => e.User)
            .FirstOrDefaultAsync(e => e.Id == id);
    }

    public async Task<Employee?> GetEmployeeByUserIdAsync(string userId)
    {
        return await _context.Employees
            .Include(e => e.User)
            .FirstOrDefaultAsync(e => e.UserId == userId);
    }

    public async Task<bool> CreateEmployeeAsync(CreateEmployeeViewModel model, string managerId)
    {
        var user = new User
        {
            UserName = model.Email,
            Email = model.Email,
            FirstName = model.FirstName,
            LastName = model.LastName,
            PhoneNumber = model.Phone,
            Address = model.Address,
            Role = Roles.Receptionist, // Default role
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };

        var result = await _userManager.CreateAsync(user, model.Password);
        if (!result.Succeeded)
        {
            throw new Exception(string.Join(", ", result.Errors.Select(e => e.Description)));
        }

        await _userManager.AddToRoleAsync(user, Roles.Receptionist);

        var employee = new Employee
        {
            UserId = user.Id,
            JobTitle = model.Position,
            Department = "General",
            HireDate = model.HireDate,
            Salary = model.Salary,
            IsActive = model.IsActive,
            Phone = model.Phone,
            Address = model.Address,
            ProfilePicture = model.ProfilePicture
        };

        _context.Employees.Add(employee);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> UpdateEmployeeAsync(Guid id, UpdateEmployeeViewModel model)
    {
        var employee = await GetEmployeeByIdAsync(id);
        if (employee == null) return false;

        employee.JobTitle = model.Position;
        employee.HireDate = model.HireDate;
        employee.Salary = model.Salary;
        employee.IsActive = model.IsActive;
        employee.Phone = model.Phone;
        employee.Address = model.Address;
        if (model.ProfilePicture != null)
        {
            employee.ProfilePicture = model.ProfilePicture;
        }

        if (employee.User != null)
        {
            employee.User.FirstName = model.FirstName;
            employee.User.LastName = model.LastName;
            employee.User.PhoneNumber = model.Phone;
            await _userManager.UpdateAsync(employee.User);
        }

        _context.Employees.Update(employee);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> DeleteEmployeeAsync(Guid id)
    {
        var employee = await GetEmployeeByIdAsync(id);
        if (employee == null) return false;

        employee.IsActive = false;
        if (employee.User != null)
        {
            employee.User.IsActive = false;
            await _userManager.UpdateAsync(employee.User);
        }
        
        _context.Employees.Update(employee);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> UpdateEmployeeStatusAsync(Guid id, bool isActive)
    {
        var employee = await GetEmployeeByIdAsync(id);
        if (employee == null) return false;

        employee.IsActive = isActive;
        if (employee.User != null)
        {
            employee.User.IsActive = isActive;
            await _userManager.UpdateAsync(employee.User);
        }

        _context.Employees.Update(employee);
        return await _context.SaveChangesAsync() > 0;
    }
}

public interface IRefreshTokenService
{
    Task<string> GenerateRefreshTokenAsync(User user);
}

public class RefreshTokenService : IRefreshTokenService
{
    public async Task<string> GenerateRefreshTokenAsync(User user)
    {
        return Guid.NewGuid().ToString();
    }
}
