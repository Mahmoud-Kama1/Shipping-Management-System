using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Shipy.Models.ViewModels;
using Shipy.Services;

namespace Shipy.Controllers;

[Authorize(Policy = "AdminOnly")]
public class CourierController : Controller
{
    private readonly ICourierService _courierService;
    private readonly IGovernorateService _governorateService;

    public CourierController(ICourierService courierService, IGovernorateService governorateService)
    {
        _courierService = courierService;
        _governorateService = governorateService;
    }

    public async Task<IActionResult> Index()
    {
        var couriers = await _courierService.GetAllCouriersAsync();
        return View(couriers);
    }

    public async Task<IActionResult> Details(Guid id)
    {
        var courier = await _courierService.GetCourierByIdAsync(id);
        if (courier == null)
        {
            return NotFound();
        }
        return View(courier);
    }

    public async Task<IActionResult> Create()
    {
        await PopulateDropdowns();
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateCourierViewModel model)
    {
        if (ModelState.IsValid)
        {
            var result = await _courierService.CreateCourierAsync(model);
            
            TempData["Success"] = "Courier created successfully!";
            return RedirectToAction(nameof(Index));
        }

        await PopulateDropdowns();
        return View(model);
    }

    public async Task<IActionResult> Edit(Guid id)
    {
        var courier = await _courierService.GetCourierByIdAsync(id);
        if (courier == null)
        {
            return NotFound();
        }

        var model = new UpdateCourierViewModel
        {
            Name = courier.Name,
            Phone = courier.Phone,
            IsAvailable = courier.IsAvailable,
            ManagerId = courier.ManagerId
        };

        await PopulateDropdowns();
        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(Guid id, UpdateCourierViewModel model)
    {
        if (ModelState.IsValid)
        {
            var result = await _courierService.UpdateCourierAsync(id, model);
            if (result)
            {
                TempData["Success"] = "Courier updated successfully!";
                return RedirectToAction(nameof(Index));
            }
        }

        await PopulateDropdowns();
        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Delete(Guid id)
    {
        var result = await _courierService.DeleteCourierAsync(id);
        if (result)
        {
            TempData["Success"] = "Courier deleted successfully!";
        }
        else
        {
            TempData["Error"] = "Failed to delete courier.";
        }

        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> UpdateAvailability(Guid id, bool isAvailable)
    {
        var result = await _courierService.UpdateCourierAvailabilityAsync(id, isAvailable);
        
        if (result)
        {
            TempData["Success"] = $"Courier availability updated to {(isAvailable ? "Available" : "Unavailable")}!";
        }
        else
        {
            TempData["Error"] = "Failed to update courier availability.";
        }

        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost]
    public async Task<IActionResult> AssignGovernorate(Guid courierId, int governorateId)
    {
        var result = await _courierService.AssignGovernorateToCourierAsync(courierId, governorateId);
        
        if (result)
        {
            TempData["Success"] = "Governorate assigned to courier successfully!";
        }
        else
        {
            TempData["Error"] = "Failed to assign governorate to courier.";
        }

        return RedirectToAction(nameof(Details), new { id = courierId });
    }

    [HttpPost]
    public async Task<IActionResult> RemoveGovernorate(Guid courierId, int governorateId)
    {
        var result = await _courierService.RemoveGovernorateFromCourierAsync(courierId, governorateId);
        
        if (result)
        {
            TempData["Success"] = "Governorate removed from courier successfully!";
        }
        else
        {
            TempData["Error"] = "Failed to remove governorate from courier.";
        }

        return RedirectToAction(nameof(Details), new { id = courierId });
    }

    private async Task PopulateDropdowns()
    {
        // This would typically populate managers from user service
        // For now, leaving empty as it's not critical for demo
        ViewBag.Managers = new SelectList(new List<object>(), "Value", "Text");
    }
}
