using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Shipy.Models.Entities;

namespace Shipy.Data;

public static class SeedData
{
    public static async Task Initialize(IServiceProvider serviceProvider)
    {
        var roleManager = serviceProvider.GetRequiredService<RoleManager<AppRole>>();
        var userManager = serviceProvider.GetRequiredService<UserManager<User>>();
        var context = serviceProvider.GetRequiredService<ApplicationDbContext>();

        // Seed Roles
        string[] roleNames = { Roles.Admin, Roles.Receptionist, Roles.Courier, Roles.Merchant, Roles.Customer };
        foreach (var roleName in roleNames)
        {
            if (!await roleManager.RoleExistsAsync(roleName))
            {
                await roleManager.CreateAsync(new AppRole { Name = roleName });
            }
        }

        // Seed Admin User
        var adminEmail = "admin@shipy.com";
        var adminUser = await userManager.FindByEmailAsync(adminEmail);
        if (adminUser == null)
        {
            adminUser = new User
            {
                UserName = adminEmail,
                Email = adminEmail,
                FullName = "System Administrator",
                EmailConfirmed = true,
                IsActive = true
            };
            var result = await userManager.CreateAsync(adminUser, "Admin123!");
            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(adminUser, Roles.Admin);
            }
        }
        
        // Seed Governorates if empty
        if (!await context.Governorates.AnyAsync())
        {
            var governorates = new List<Governorate>
            {
                new Governorate { Name = "Cairo", DeliveryFee = 50 },
                new Governorate { Name = "Giza", DeliveryFee = 50 },
                new Governorate { Name = "Alexandria", DeliveryFee = 70 },
                new Governorate { Name = "Mansoura", DeliveryFee = 80 }
            };
            await context.Governorates.AddRangeAsync(governorates);
            await context.SaveChangesAsync();
        }
    }
}
