# CourierHub (Local-First Demo)

A role-based courier/shipping management system running entirely in the browser (no backend). It demonstrates merchants creating shipments, receptionists registering shipments, couriers updating delivery status, and admins monitoring and managing the whole operation.

## Highlights
- Role-based UX with automatic redirect after login/signup
- Shared navbar on all authenticated pages with user details, per-user notifications, and logout
- Unified local storage schema for shipments with automatic legacy migration
- Merchant-specific dashboard metrics (per-account)
- Admin management views for Courier, Receptionist, and Tracking
- Debounced writes to localStorage for faster, smoother UI

## Project Structure
- `index.html` — Login and Merchant Signup (entry point)
- `Admin/Admin.html` — Admin dashboard + management sections
- `Receptionist/Receptionist.html` — Receptionist intake and list
- `Courier/Courier.html` — Courier task board
- `Tracker/tracking.html` — Tracking dashboard (demo data; can be wired to unified store)
- `merchant_ui/Pages/dashboard.html` — Merchant dashboard
- `assets/js/common.js` — Core utilities: session, navbar, notifications, unified store, migration, small event bus
- `merchant_ui/img/` — Static images

## Getting Started
1. Open `index.html` in a modern browser (Chrome/Edge/Firefox). No server required.
2. Log in using a test account or sign up as a merchant.

### Test Accounts
- Admin: `admin@company.com` / `123`
- Receptionist: `receptionist@company.com` / `123`
- Courier: `courier@company.com` / `123`
- Merchant: Sign up via the Signup tab

## Roles and Pages
- Admin
  - Page: `Admin/Admin.html`
  - See system totals/charts and management sections:
    - Courier Management: shipments, assigned courier, city, current status
    - Receptionist Management: shipments registered via intake
    - Tracking Management: quick ID lookup
  - Navbar includes Manage Employees (add/edit/delete)

- Receptionist
  - Page: `Receptionist/Receptionist.html`
  - Register shipments, set city (auto-fee), assign courier (availability by city), list/edit/delete

- Courier
  - Page: `Courier/Courier.html`
  - View tasks, filter by status, set In Transit / Delivered / Failed with notes and history

- Merchant
  - Page: `merchant_ui/Pages/dashboard.html`
  - See personal metrics (Total, In Transit, Delivered, Pending), recent shipments, create shipments (modal)
  - Navbar includes My Profile (edit personal details)

- Tracker (demo)
  - Page: `Tracker/tracking.html`
  - Dashboard-style overview; can be adapted to read from unified store

## Unified Data Model (LocalStorage)
- Shipments: key `shipments_u1` (array of objects)
  - `id: string`
  - `ownerEmail: string | null` (merchant owning shipment)
  - `createdBy: string | null` (email of creator)
  - `recipient: { name, phone, address }`
  - `recipientGovernorate: string`
  - `assignedCourier: string` (courier id/code)
  - `pricing: { product: number, delivery: number, total: number }`
  - `status: 'Pending' | 'In Transit' | 'Delivered' | 'Failed'` (extensible)
  - `history: Array<{ status, time, note, by? }>`
  - `weight: number | null`, `type: string`, `notes: string`
  - `createdAt: number`, `updatedAt: number`

### Migration
- On first load, legacy data from `shipments_v2` (Receptionist) and `shipments` (Merchant) is migrated into `shipments_u1`.
- Schema version key: `courier_schema_version`.

## Notifications
- Key: `courier_system_notifications_v2`
- Structure: `{ id, type, message, actor: { email, role } | null, timestamp, readBy: { [email]: true } }`
- Per-user unread badge in navbar; “Mark all read” only affects the current user
- Emitted on: login/signup, shipment create/edit/delete (Receptionist), status changes (Courier), merchant-created shipment mirror, profile/employees updates

## Performance
- Debounced writes (250ms) to reduce localStorage thrash under rapid updates
- Minimal DOM work and simple filtering for snappy tables

## Security Notes (Demo Only)
- Credentials and data are stored client-side for demonstration
- Do not use in production without a secure backend, authentication, and proper access control

## Customization
- Branding: replace the simple logo block in `assets/js/common.js` or add an SVG (`assets/img/logo.svg`) and reference it in the navbar
- Governorate fee matrix: edit `DELIVERY_RATES` in `Receptionist/Receptionist.html`
- Default couriers: edit `DEFAULT_COURIERS` in `Receptionist/Receptionist.html`

## Development Guide
- Shared Core: `assets/js/common.js`
  - `CourierCommon.requireAuth()` — guard page access
  - `CourierCommon.injectNavbar()` — add role-aware navbar with notifications and logout
  - Notifications helpers (`createNotification`, per-user unread)
  - Unified store accessors, migrations, and small event bus
- Pages should read/write `shipments_u1` and the unified schema

## Known Limitations & Next Steps
- Public tracking page uses demo data — wire it to `shipments_u1` for live results
- No server-side persistence/auth; add a backend for real deployments
- Permissions are UI-enforced; introduce a central permission helper and/or backend checks
- CSV/Excel export and richer filters for admin tables are recommended for scale

## License
This project is provided for demonstration and educational purposes.


