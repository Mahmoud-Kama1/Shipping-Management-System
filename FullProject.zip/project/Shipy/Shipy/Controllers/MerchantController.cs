using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Shipy.Models.ViewModels;
using Shipy.Services;

namespace Shipy.Controllers;

[Authorize(Roles = "Merchant")]
public class MerchantController : Controller
{
    private readonly IMerchantService _merchantService;
    private readonly IGovernorateService _governorateService;
    private readonly ICourierService _courierService;

    public MerchantController(IMerchantService merchantService, IGovernorateService governorateService, ICourierService courierService)
    {
        _merchantService = merchantService;
        _governorateService = governorateService;
        _courierService = courierService;
    }

    public async Task<IActionResult> Index()
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
        {
            return RedirectToAction("Login", "Account");
        }

        var dashboardData = await _merchantService.GetMerchantDashboardAsync(userId);
        return View(dashboardData);
    }

    public async Task<IActionResult> Shipments()
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
        {
            return RedirectToAction("Login", "Account");
        }

        var shipments = await _merchantService.GetMerchantShipmentsAsync(userId);
        return View(shipments);
    }

    public async Task<IActionResult> CreateShipment()
    {
        await PopulateDropdowns();
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> CreateShipment(CreateShipmentViewModel model)
    {
        if (ModelState.IsValid)
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
            {
                return RedirectToAction("Login", "Account");
            }

            var result = await _merchantService.CreateMerchantShipmentAsync(model, userId);
            
            TempData["Success"] = "Shipment created successfully!";
            return RedirectToAction(nameof(Shipments));
        }

        await PopulateDropdowns();
        return View(model);
    }

    public async Task<IActionResult> EditShipment(Guid id)
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
        {
            return RedirectToAction("Login", "Account");
        }

        var shipments = await _merchantService.GetMerchantShipmentsAsync(userId);
        var shipment = shipments.FirstOrDefault(s => s.Id == id);
        
        if (shipment == null)
        {
            return NotFound();
        }

        var model = new UpdateShipmentViewModel
        {
            SenderName = shipment.SenderName,
            SenderPhone = shipment.SenderPhone,
            RecipientName = shipment.RecipientName,
            RecipientPhone = shipment.RecipientPhone,
            RecipientAddress = shipment.RecipientAddress,
            Weight = shipment.Weight,
            Type = shipment.Type,
            ProductPrice = shipment.ProductPrice,
            DeliveryPrice = shipment.DeliveryPrice,
            GovernorateId = shipment.GovernorateId,
            CourierId = shipment.CourierId,
            Notes = shipment.Notes
        };

        await PopulateDropdowns();
        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> EditShipment(Guid id, UpdateShipmentViewModel model)
    {
        if (ModelState.IsValid)
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
            {
                return RedirectToAction("Login", "Account");
            }

            var result = await _merchantService.UpdateMerchantShipmentAsync(id, model, userId);
            if (result)
            {
                TempData["Success"] = "Shipment updated successfully!";
                return RedirectToAction(nameof(Shipments));
            }
        }

        await PopulateDropdowns();
        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> DeleteShipment(Guid id)
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
        {
            return RedirectToAction("Login", "Account");
        }

        var result = await _merchantService.DeleteMerchantShipmentAsync(id, userId);
        if (result)
        {
            TempData["Success"] = "Shipment deleted successfully!";
        }
        else
        {
            TempData["Error"] = "Failed to delete shipment.";
        }

        return RedirectToAction(nameof(Shipments));
    }

    private async Task PopulateDropdowns()
    {
        var governorates = await _governorateService.GetAllGovernoratesAsync();
        ViewBag.Governorates = new SelectList(governorates, "Id", "Name");

        var couriers = await _courierService.GetAvailableCouriersAsync();
        ViewBag.Couriers = new SelectList(couriers, "Id", "Name");
    }
}
